---
name: Bug report
about: Describe a problem
title: ''
labels: ''
assignees: ''

---

**Read Troubleshoot**

[x] I admit that I have read the [Troubleshoot](https://github.com/lllyasviel/Fooocus/blob/main/troubleshoot.md) before making this issue.

**Describe the problem**
A clear and concise description of what the bug is.

**Full Console Log**
Paste **full** console log here. You will make our job easier if you give a **full** log.
